abstract class UserStates {}

class UserInitState extends UserStates {}

//////////////////////////////////////

class GetUserAllServicesSuccessState extends UserStates {}

class GetUserAllServicesLoadingState extends UserStates {}

class GetUserAllServicesErrorState extends UserStates {
  final String error;

  GetUserAllServicesErrorState({required this.error});
}

//////////////////////////////////////

class GetUserSpecServicesSuccessState extends UserStates {}

class GetUserSpecServicesLoadingState extends UserStates {}

class GetUserSpecServicesErrorState extends UserStates {
  final String error;

  GetUserSpecServicesErrorState({required this.error});
}

//////////////////////////////////////

class GetCategoryLoadingState extends UserStates {}

class GetCategorySuccessState extends UserStates {}

class GetCategoryErrorState extends UserStates {
  final String error;

  GetCategoryErrorState({required this.error});
}

//////////////////////////////////////

class GetUserRequestSuccessState extends UserStates {}

class GetUserRequestLoadingState extends UserStates {}

class GetUserRequestErrorState extends UserStates {
  final String error;

  GetUserRequestErrorState({required this.error});
}

//////////////////////////////////////

class CreateRequestSuccessState extends UserStates {}

class CreateRequestLoadingState extends UserStates {}

class CreateRequestErrorState extends UserStates {
  final String error;

  CreateRequestErrorState({required this.error});
}

//////////////////////////////////////

class EditUserDataLoadingState extends UserStates {}

class EditUserDataSuccessState extends UserStates {}

class EditUserDataErrorState extends UserStates {
  final String error;

  EditUserDataErrorState({required this.error});
}

//////////////////////////////////////

class CreateOrGetChatLoadingState extends UserStates {}

class CreateOrGetChatSuccessState extends UserStates {
  final String chatId;

  CreateOrGetChatSuccessState({required this.chatId});
}

class CreateOrGetChatErrorState extends UserStates {
  final String error;

  CreateOrGetChatErrorState({required this.error});
}

//////////////////////////////////////


class GetSingleUserDataLoadingState extends UserStates {}

class GetSingleUserDataSuccessState extends UserStates {}

class GetSingleUserDataErrorState extends UserStates {
  final String error;

  GetSingleUserDataErrorState({required this.error});
}

//////////////////////////////////////

class ConfirmBookingReviewLoadingState extends UserStates {}

class ConfirmBookingReviewSuccessState extends UserStates {}

class ConfirmBookingReviewErrorState extends UserStates {
  final String error;

  ConfirmBookingReviewErrorState({required this.error});
}

//////////////////////////////////////

class GetServiceReviewsLoadingState extends UserStates {}

class GetServiceReviewsSuccessState extends UserStates {}

class GetServiceReviewsErrorState extends UserStates {
  final String error;

  GetServiceReviewsErrorState({required this.error});
}

//////////////////////////////////////

class CancelRequestLoadingState extends UserStates {}

class CancelRequestSuccessState extends UserStates {}

class CancelRequestErrorState extends UserStates {
  final String error;

  CancelRequestErrorState({required this.error});
}